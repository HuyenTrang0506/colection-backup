package vn.titv.spring.hibernate.dao;

import vn.titv.spring.hibernate.entity.Course;

public interface CourseDAO {

    public void save(Course course);

}
